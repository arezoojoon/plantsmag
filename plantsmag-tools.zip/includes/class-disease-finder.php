<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PlantsMag_Disease_Finder {

	public function __construct() {
		add_shortcode( 'plant_disease_finder', array( $this, 'render_shortcode' ) );
	}

	public function render_shortcode( $atts ) {
		ob_start();
		?>
		<div style="width: 100%; max-width: 448px; margin: 0 auto;">
			<iframe 
				id="pm-disease-iframe" 
				src="http://72.62.93.117:3000/disease-finder" 
				style="width: 1px; min-width: 100%; border: none;" 
				scrolling="no">
			</iframe>
		</div>
		<script src="https://cdnjs.cloudflare.com/ajax/libs/iframe-resizer/4.3.9/iframeResizer.min.js"></script>
		<script>
			document.addEventListener("DOMContentLoaded", function() {
				iFrameResize({ log: false, checkOrigin: false }, '#pm-disease-iframe');
			});
		</script>
		<?php
		return ob_get_clean();
	}
}

new PlantsMag_Disease_Finder();
