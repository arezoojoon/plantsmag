<?php
/**
 * Plugin Name: PlantsMag Premium Tools
 * Plugin URI: https://plantsmag.com
 * Description: Premium Native-Like Tools for PlantsMag: Watering Calculator and AI Disease Finder.
 * Version: 1.0.0
 * Author: PlantsMag
 * Author URI: https://plantsmag.com
 * Text Domain: plantsmag-tools
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

define( 'PLANTSMAG_TOOLS_VERSION', '1.0.0' );
define( 'PLANTSMAG_TOOLS_DIR', plugin_dir_path( __FILE__ ) );
define( 'PLANTSMAG_TOOLS_URL', plugin_dir_url( __FILE__ ) );

// Include necessary files
require_once PLANTSMAG_TOOLS_DIR . 'includes/class-watering-calculator.php';
require_once PLANTSMAG_TOOLS_DIR . 'includes/class-disease-finder.php';

/**
 * Enqueue generic/global assets if needed
 */
function plantsmag_tools_enqueue_global_scripts() {
	// Add native-like generic fonts (Inter) if the theme doesn't have it
    wp_enqueue_style('plantsmag-fonts', 'https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap', array(), null);
}
add_action( 'wp_enqueue_scripts', 'plantsmag_tools_enqueue_global_scripts' );
