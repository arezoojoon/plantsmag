<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PlantsMag_Watering_Calculator {

	public function __construct() {
		add_shortcode( 'watering_calculator', array( $this, 'render_shortcode' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_assets' ) );
	}

	public function enqueue_assets() {
		global $post;
		// Only load assets if the shortcode is on the page
		if ( is_a( $post, 'WP_Post' ) && has_shortcode( $post->post_content, 'watering_calculator' ) ) {
			wp_enqueue_style( 'pm-watering-calc-css', get_template_directory_uri() . '/assets/css/watering-calculator.css', array(), wp_get_theme()->get('Version') );
			wp_enqueue_script( 'pm-watering-calc-js', get_template_directory_uri() . '/assets/js/watering-calculator.js', array( 'jquery' ), wp_get_theme()->get('Version'), true );
            
            // Pass any needed variables to JS
            wp_localize_script( 'pm-watering-calc-js', 'pmCalcObj', array(
                'ajaxUrl' => admin_url( 'admin-ajax.php' )
            ));
		}
	}

	public function render_shortcode( $atts ) {
		ob_start();
		?>
		<div class="pm-app-container pm-calculator-app">
			<div class="pm-app-header">
				<h2>Smart Watering Calculator</h2>
				<p>Find out exactly when to water your plants.</p>
			</div>

			<form id="pm-watering-form" class="pm-app-body">
				<!-- Plant Type -->
				<div class="pm-input-group">
					<label for="plant-type">Plant Type</label>
					<div class="pm-select-wrapper">
						<select id="plant-type" required>
							<option value="" disabled selected>Select your plant...</option>
							<option value="succulent">Succulent / Cactus</option>
							<option value="tropical">Monstera / Tropical</option>
							<option value="fern">Fern</option>
							<option value="herb">Indoor Herb</option>
							<option value="snake">Snake Plant / ZZ Plant</option>
						</select>
					</div>
				</div>

				<!-- Pot Size/Type -->
				<div class="pm-input-group">
					<label for="pot-type">Pot Material</label>
					<div class="pm-options-row">
						<label class="pm-radio-card">
							<input type="radio" name="pot-type" value="terracotta" required>
							<span class="pm-card-content">Terracotta<br><small>Dries fast</small></span>
						</label>
						<label class="pm-radio-card">
							<input type="radio" name="pot-type" value="plastic">
							<span class="pm-card-content">Plastic/Ceramic<br><small>Holds water</small></span>
						</label>
					</div>
				</div>

                <!-- Light Conditions -->
                <div class="pm-input-group">
					<label for="light-level">Light Condition</label>
					<div class="pm-options-row">
						<label class="pm-radio-card">
							<input type="radio" name="light-level" value="low" required>
							<span class="pm-card-content">Low Light</span>
						</label>
						<label class="pm-radio-card">
							<input type="radio" name="light-level" value="medium">
							<span class="pm-card-content">Medium Light</span>
						</label>
                        <label class="pm-radio-card">
							<input type="radio" name="light-level" value="bright">
							<span class="pm-card-content">Bright Light</span>
						</label>
					</div>
				</div>

				<button type="submit" class="pm-btn-primary">Calculate Schedule</button>
			</form>

			<!-- Result Bottom Sheet -->
			<div id="pm-result-sheet" class="pm-bottom-sheet">
                <div class="pm-sheet-handler"></div>
				<div class="pm-sheet-content">
					<h3>Your Watering Schedule</h3>
					<div class="pm-result-highlight">
						<span id="pm-days-result">7</span>
						<small>Days</small>
					</div>
					<p class="pm-result-desc" id="pm-result-message">Water your plant every 7 days. Check the top 2 inches of soil before watering.</p>
					
					<div class="pm-affiliate-box">
						<h4>Pro Tip for Perfect Watering</h4>
						<p>Never overwater again. Use a smart moisture meter!</p>
						<a href="#" target="_blank" class="pm-btn-outline" id="pm-affiliate-link">Get Soil Moisture Sensor ➔</a>
					</div>

                    <button type="button" class="pm-btn-secondary" id="pm-close-sheet">Recalculate</button>
				</div>
			</div>
            <div id="pm-overlay" class="pm-overlay"></div>
		</div>
		<?php
		return ob_get_clean();
	}
}

new PlantsMag_Watering_Calculator();
