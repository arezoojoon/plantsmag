import { NextRequest, NextResponse } from 'next/server';

const API_KEYS = [
    'AIzaSyACW_McR0Ow44qTwak1IfvcL-rXfThQak0'
];

const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization, X-WP-Nonce',
};

export async function OPTIONS(req: NextRequest) {
    return NextResponse.json({}, { headers: corsHeaders });
}

export async function POST(req: NextRequest) {
    try {
        const body = await req.json();
        
        if (!body.image_base64) {
            return NextResponse.json({ success: false, message: 'No image provided.' }, { status: 400, headers: corsHeaders });
        }

        let base64_string = body.image_base64;
        base64_string = base64_string.replace(/^data:image\/\w+;base64,/, '');

        const api_key = API_KEYS[Math.floor(Math.random() * API_KEYS.length)];
        const model = "gemini-2.5-flash"; 
        const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${api_key}`;

        const prompt = `You are an expert botanist and plant pathologist. Analyze this image of a plant. 
        1. Identify the plant if possible.
        2. Identify any visible diseases, pests, or deficiencies.
        3. Provide a brief, simple explanation suitable for a beginner.
        4. Recommend a generic treatment (e.g., 'Neem Oil', 'Copper Fungicide', 'Nitrogen Fertilizer', 'Yellow Sticky Traps').
        Format your response EXACTLY like this JSON:
        {
            "diagnosis": "Short name of the problem (e.g. Powdery Mildew, Spider Mites)",
            "explanation": "2-3 sentences explaining what it is and why it happens.",
            "treatment_keyword": "Generic name of treatment",
            "treatment_desc": "1 sentence on how to apply the treatment."
        }
        Only output the valid JSON without markdown block wrappers.`;

        const geminiPayload = {
            contents: [
                {
                    parts: [
                        { text: prompt },
                        {
                            inlineData: {
                                mimeType: 'image/jpeg',
                                data: base64_string
                            }
                        }
                    ]
                }
            ],
            generationConfig: {
                temperature: 0.2,
                responseMimeType: 'application/json'
            }
        };

        const response = await fetch(url, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify(geminiPayload)
        });

        if (!response.ok) {
            const errData = await response.json();
            return NextResponse.json({ success: false, message: 'AI API Error: ' + (errData.error?.message || 'Unknown Error') }, { status: 500, headers: corsHeaders });
        }

        const data = await response.json();

        if (data.candidates && data.candidates[0].content.parts[0].text) {
            let json_txt = data.candidates[0].content.parts[0].text;
            json_txt = json_txt.replace(/```json/g, '').replace(/```/g, '').trim();
            try {
                const result = JSON.parse(json_txt);
                return NextResponse.json({ success: true, data: result }, { headers: corsHeaders });
            } catch (e) {
                return NextResponse.json({ success: false, message: 'AI returned an invalid format.' }, { status: 500, headers: corsHeaders });
            }
        }

        return NextResponse.json({ success: false, message: 'AI could not process the image. Please try a clearer photo.' }, { status: 500, headers: corsHeaders });

    } catch (error) {
        return NextResponse.json({ success: false, message: 'Server connection failed.' }, { status: 500, headers: corsHeaders });
    }
}
