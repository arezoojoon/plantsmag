"use client";
import React, { useState } from "react";
import { Droplets, Sun, Sprout, Box, RefreshCw, Info } from "lucide-react";

export default function WateringCalculatorApp() {
  const [formData, setFormData] = useState({
    plantType: "tropical",
    lightLevel: "medium",
    soilType: "standard",
    potSize: "medium"
  });

  const [result, setResult] = useState<{ days: number; range: string; advice: string } | null>(null);

  const calculateWatering = () => {
    let baseDays = 7; // default 1 week

    // 1. Plant Type Multiplier
    switch (formData.plantType) {
      case "succulent": baseDays = 14; break;
      case "cacti": baseDays = 21; break;
      case "fern": baseDays = 4; break;
      case "tropical": baseDays = 7; break;
    }

    // 2. Light Level Multiplier
    let lightMultiplier = 1;
    switch (formData.lightLevel) {
      case "low": lightMultiplier = 1.3; break; // dries slower
      case "medium": lightMultiplier = 1; break;
      case "bright": lightMultiplier = 0.8; break; // dries faster
      case "direct": lightMultiplier = 0.6; break;
    }

    // 3. Soil Type Multiplier
    let soilMultiplier = 1;
    switch (formData.soilType) {
      case "peat": soilMultiplier = 1.2; break; // holds water
      case "standard": soilMultiplier = 1; break;
      case "perlite": soilMultiplier = 0.8; break; // drains fast
      case "sandy": soilMultiplier = 0.6; break;
    }

    // 4. Pot Size Multiplier
    let potMultiplier = 1;
    switch (formData.potSize) {
      case "small": potMultiplier = 0.7; break; // dries fast
      case "medium": potMultiplier = 1; break;
      case "large": potMultiplier = 1.5; break; // holds moisture long
    }

    let finalDays = Math.round(baseDays * lightMultiplier * soilMultiplier * potMultiplier);
    
    // Bounds check
    if (finalDays < 1) finalDays = 1;
    if (finalDays > 30) finalDays = 30;

    let advice = "Always check the top 2 inches of soil before watering.";
    if (formData.plantType === "succulent" || formData.plantType === "cacti") {
      advice = "Wait until the soil is completely 100% dry before watering again.";
    } else if (formData.plantType === "fern") {
      advice = "Keep the soil consistently moist, but not soggy.";
    }

    setResult({
      days: finalDays,
      range: `${Math.max(1, finalDays - 1)} to ${finalDays + 2}`,
      advice
    });
  };

  return (
    <div className="w-full bg-white overflow-hidden font-sans">
      <div className="bg-emerald-700 p-6 text-center rounded-t-2xl">
        <h2 className="text-2xl font-bold text-white mb-1 flex items-center justify-center gap-2">
          <Droplets size={24} /> Smart Watering
        </h2>
        <p className="text-blue-100 text-sm">Calculate the perfect watering schedule</p>
      </div>

      <div className="p-6 space-y-5">
        {/* Plant Type */}
        <div>
          <label className="flex items-center gap-2 text-gray-700 font-semibold mb-2 text-sm">
            <Sprout size={16} className="text-emerald-500" /> Plant Type
          </label>
          <div className="grid grid-cols-2 gap-2">
            {[
              { id: "tropical", label: "Tropical (Monstera, Pothos)" },
              { id: "succulent", label: "Succulent" },
              { id: "cacti", label: "Cactus" },
              { id: "fern", label: "Fern / Calathea" }
            ].map((pt) => (
              <button
                key={pt.id}
                onClick={() => setFormData({ ...formData, plantType: pt.id })}
                className={`py-2 px-3 text-xs font-medium rounded-xl border transition-colors text-left ${
                  formData.plantType === pt.id
                    ? "bg-blue-50 border-blue-500 text-blue-700"
                    : "bg-white border-gray-200 text-gray-600 hover:border-blue-200"
                }`}
              >
                {pt.label}
              </button>
            ))}
          </div>
        </div>

        {/* Light Level */}
        <div>
          <label className="flex items-center gap-2 text-gray-700 font-semibold mb-2 text-sm">
            <Sun size={16} className="text-amber-500" /> Light Exposure
          </label>
          <select
            value={formData.lightLevel}
            onChange={(e) => setFormData({ ...formData, lightLevel: e.target.value })}
            className="w-full bg-gray-50 border border-gray-200 text-gray-700 rounded-xl px-4 py-3 outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-all"
          >
            <option value="low">Low Light (North window, far from light)</option>
            <option value="medium">Medium Light (East window)</option>
            <option value="bright">Bright Indirect (South/West window, filtered)</option>
            <option value="direct">Direct Sun (Unfiltered South window)</option>
          </select>
        </div>

        {/* Soil Type */}
        <div>
          <label className="flex items-center gap-2 text-gray-700 font-semibold mb-2 text-sm">
            <Droplets size={16} className="text-blue-400" /> Soil Drainage
          </label>
          <select
            value={formData.soilType}
            onChange={(e) => setFormData({ ...formData, soilType: e.target.value })}
            className="w-full bg-gray-50 border border-gray-200 text-gray-700 rounded-xl px-4 py-3 outline-none focus:border-blue-400 focus:ring-2 focus:ring-blue-100 transition-all"
          >
            <option value="perlite">Chunky / Well-Draining (Lots of perlite/bark)</option>
            <option value="standard">Standard Potting Mix</option>
            <option value="peat">Moisture Retaining (Heavy peat moss)</option>
            <option value="sandy">Sandy (Cactus Mix)</option>
          </select>
        </div>

        {/* Pot Size */}
        <div>
          <label className="flex items-center gap-2 text-gray-700 font-semibold mb-2 text-sm">
            <Box size={16} className="text-indigo-400" /> Pot Size
          </label>
          <div className="flex gap-2">
            {[
              { id: "small", label: "Small (< 6\")" },
              { id: "medium", label: "Medium (6\"-10\")" },
              { id: "large", label: "Large (> 10\")" }
            ].map((pot) => (
              <button
                key={pot.id}
                onClick={() => setFormData({ ...formData, potSize: pot.id })}
                className={`flex-1 py-2 text-xs font-medium rounded-xl border transition-colors ${
                  formData.potSize === pot.id
                    ? "bg-blue-50 border-blue-500 text-blue-700"
                    : "bg-white border-gray-200 text-gray-600 hover:border-blue-200"
                }`}
              >
                {pot.label}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={calculateWatering}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-4 rounded-2xl shadow-lg shadow-blue-200 transition-all mt-4"
        >
          Calculate Schedule
        </button>

        {result && (
          <div className="mt-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="bg-gradient-to-br from-blue-50 to-cyan-50 rounded-2xl p-5 border border-blue-100 text-center">
              <p className="text-blue-800 font-semibold mb-1">Estimated Watering Frequency:</p>
              <h3 className="text-4xl font-black text-blue-600 mb-2">Every {result.range} Days</h3>
              <div className="flex items-start gap-2 bg-white/60 p-3 rounded-xl text-left mt-4 border border-blue-100">
                <Info size={18} className="text-blue-500 shrink-0 mt-0.5" />
                <p className="text-sm text-gray-700">{result.advice}</p>
              </div>
            </div>

            <div className="mt-4 p-4 bg-amber-50 rounded-xl border border-amber-100">
              <p className="text-sm text-amber-800">
                <strong>Pro Tip:</strong> Stop guessing when to water. A simple moisture meter is the best investment for your plants.
              </p>
              <a 
                href="https://www.amazon.com/dp/B01IGQOIN2?tag=plantsmag-20" 
                target="_blank" 
                rel="noopener noreferrer"
                className="mt-3 block text-center bg-amber-500 hover:bg-amber-600 text-white font-bold py-2 px-4 rounded-lg text-sm transition-colors"
              >
                Get a Digital Moisture Meter
              </a>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
