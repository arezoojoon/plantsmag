"use client";
import React, { useState, useRef } from "react";
import { UploadCloud, Activity, CheckCircle2, ChevronRight, RefreshCw, X } from "lucide-react";

export default function DiseaseFinderApp() {
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.match("image.*")) {
      setError("Please select a valid image file (JPEG or PNG).");
      return;
    }

    const reader = new FileReader();
    reader.onload = (event) => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const MAX_WIDTH = 600;
        const MAX_HEIGHT = 600;
        let width = img.width;
        let height = img.height;

        if (width > height) {
          if (width > MAX_WIDTH) {
            height *= MAX_WIDTH / width;
            width = MAX_WIDTH;
          }
        } else {
          if (height > MAX_HEIGHT) {
            width *= MAX_HEIGHT / height;
            height = MAX_HEIGHT;
          }
        }
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext("2d");
        ctx?.drawImage(img, 0, 0, width, height);

        const base64 = canvas.toDataURL("image/jpeg", 0.8);
        setImageSrc(base64);
        setResult(null);
        setError(null);
      };
      if (event.target?.result) {
        img.src = event.target.result as string;
      }
    };
    reader.readAsDataURL(file);
  };

  const analyzePlant = async () => {
    if (!imageSrc) return;
    setIsAnalyzing(true);
    setError(null);

    try {
      const res = await fetch("/api/analyze-disease", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ image_base64: imageSrc }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.message || "Could not analyze the image.");
      }

      setResult(data.data);
    } catch (err: any) {
      setError(err.message || "An error occurred.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getAffiliateLink = (keyword: string) => {
    const kw = keyword.toLowerCase();
    if (kw.includes("neem")) return "https://www.amazon.com/dp/B004QAWGIO?tag=plantsmag-20";
    if (kw.includes("copper") || kw.includes("fungicide")) return "https://www.amazon.com/dp/B000RUJZS6?tag=plantsmag-20";
    if (kw.includes("sticky") || kw.includes("trap")) return "https://www.amazon.com/dp/B07XLM4NWV?tag=plantsmag-20";
    if (kw.includes("fertilizer") || kw.includes("food") || kw.includes("nitrogen")) return "https://www.amazon.com/dp/B000OV8WTM?tag=plantsmag-20";
    return `https://www.amazon.com/s?k=${encodeURIComponent(keyword + " for plants")}&tag=plantsmag-20`;
  };

  return (
    <div className="w-full bg-white overflow-hidden font-sans">
      <div className="bg-emerald-600 p-6 text-center relative overflow-hidden rounded-t-2xl">
        <div className="absolute top-0 right-0 p-2">
          <span className="inline-flex items-center gap-1 bg-emerald-500/50 text-white text-xs px-2 py-1 rounded-full border border-emerald-400">
            <Activity size={12} /> AI Powered
          </span>
        </div>
        <h2 className="text-2xl font-bold text-white mt-4 mb-1">Plant Doctor</h2>
        <p className="text-emerald-100 text-sm">Instant diagnosis & treatment</p>
      </div>

      <div className="p-6">
        {error && (
          <div className="mb-4 p-3 bg-red-50 text-red-600 text-sm rounded-xl flex items-start gap-2">
            <X size={18} className="shrink-0 mt-0.5" />
            <p>{error}</p>
          </div>
        )}

        {!imageSrc ? (
          <div 
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-emerald-200 rounded-2xl p-8 text-center cursor-pointer hover:border-emerald-500 hover:bg-emerald-50 transition-all duration-300 group"
          >
            <div className="w-16 h-16 mx-auto bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mb-4 group-hover:scale-110 transition-transform">
              <UploadCloud size={32} />
            </div>
            <h3 className="text-lg font-semibold text-gray-800 mb-1">Tap to Scan Plant</h3>
            <p className="text-sm text-gray-500">Take a photo or upload from gallery</p>
            <input 
              type="file" 
              ref={fileInputRef} 
              className="hidden" 
              accept="image/*" 
              capture="environment" 
              onChange={handleImageUpload} 
            />
          </div>
        ) : (
          <div className="relative rounded-2xl overflow-hidden shadow-inner bg-gray-100 mb-6 group">
            <img src={imageSrc} alt="Scanned plant" className="w-full h-64 object-cover" />
            {!isAnalyzing && !result && (
              <button 
                onClick={() => setImageSrc(null)}
                className="absolute top-2 right-2 bg-black/50 text-white p-2 rounded-full hover:bg-red-500 transition-colors"
              >
                <X size={16} />
              </button>
            )}
          </div>
        )}

        {imageSrc && !result && (
          <button 
            onClick={analyzePlant} 
            disabled={isAnalyzing}
            className="w-full bg-emerald-600 hover:bg-emerald-700 disabled:bg-emerald-400 text-white font-semibold py-4 px-6 rounded-2xl shadow-lg shadow-emerald-200 transition-all flex justify-center items-center gap-2"
          >
            {isAnalyzing ? (
              <>
                <RefreshCw size={20} className="animate-spin" />
                Analyzing Leaves...
              </>
            ) : (
              <>
                <Activity size={20} />
                Analyze Plant
              </>
            )}
          </button>
        )}

        {result && (
          <div className="space-y-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
            <div className="bg-emerald-50 rounded-2xl p-5 border border-emerald-100">
              <div className="flex items-center gap-2 text-emerald-700 font-bold text-lg mb-2">
                <CheckCircle2 size={22} className="text-emerald-500" />
                {result.diagnosis}
              </div>
              <p className="text-gray-700 text-sm leading-relaxed">{result.explanation}</p>
            </div>

            <div className="bg-amber-50 rounded-2xl p-5 border border-amber-100">
              <h4 className="text-amber-800 font-semibold mb-2">Recommended Treatment</h4>
              <p className="text-amber-900/80 text-sm mb-4">{result.treatment_desc}</p>
              
              <a 
                href={getAffiliateLink(result.treatment_keyword)} 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center justify-between w-full bg-amber-500 hover:bg-amber-600 text-white font-bold py-3 px-5 rounded-xl transition-colors shadow-md shadow-amber-200"
              >
                <span>Get {result.treatment_keyword}</span>
                <ChevronRight size={20} />
              </a>
            </div>

            <button 
              onClick={() => { setImageSrc(null); setResult(null); }}
              className="w-full text-center py-3 text-emerald-600 hover:text-emerald-800 text-sm font-semibold transition-colors"
            >
              Scan Another Plant
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
