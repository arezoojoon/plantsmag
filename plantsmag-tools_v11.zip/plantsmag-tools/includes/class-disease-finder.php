<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PlantsMag_Disease_Finder {

	public function __construct() {
		add_shortcode( 'plant_disease_finder', array( $this, 'render_shortcode' ) );
		
		// Register AJAX endpoints
		add_action( 'wp_ajax_pm_analyze_disease', array( $this, 'analyze_disease_ajax' ) );
		add_action( 'wp_ajax_nopriv_pm_analyze_disease', array( $this, 'analyze_disease_ajax' ) );
	}

	public function analyze_disease_ajax() {
		// Verify nonce for security
		if ( ! isset( $_POST['_wpnonce'] ) || ! wp_verify_nonce( $_POST['_wpnonce'], 'pm_disease_nonce' ) ) {
			wp_send_json_error( array( 'message' => 'Security check failed.' ) );
		}

		if ( ! isset( $_POST['image_base64'] ) ) {
			wp_send_json_error( array( 'message' => 'No image provided.' ) );
		}

		$base64_string = sanitize_textarea_field( wp_unslash( $_POST['image_base64'] ) );
		$base64_string = preg_replace('/^data:image\/\w+;base64,/', '', $base64_string);

		$api_key = 'AIzaSyACW_McR0Ow44qTwak1IfvcL-rXfThQak0';
		$model = "gemini-2.5-flash"; 
		$url = "https://generativelanguage.googleapis.com/v1beta/models/{$model}:generateContent?key={$api_key}";

		$prompt = "You are an expert botanist and plant pathologist. Analyze this image of a plant. 
		1. Identify the plant if possible.
		2. Identify any visible diseases, pests, or deficiencies.
		3. Provide a brief, simple explanation suitable for a beginner.
		4. Recommend a generic treatment (e.g., 'Neem Oil', 'Copper Fungicide', 'Nitrogen Fertilizer', 'Yellow Sticky Traps').
		Format your response EXACTLY like this JSON:
		{
			\"diagnosis\": \"Short name of the problem (e.g. Powdery Mildew, Spider Mites)\",
			\"explanation\": \"2-3 sentences explaining what it is and why it happens.\",
			\"treatment_keyword\": \"Generic name of treatment\",
			\"treatment_desc\": \"1 sentence on how to apply the treatment.\"
		}
		Only output the valid JSON without markdown block wrappers.";

		$payload = array(
			'contents' => array(
				array(
					'parts' => array(
						array( 'text' => $prompt ),
						array(
							'inlineData' => array(
								'mimeType' => 'image/jpeg',
								'data'     => $base64_string
							)
						)
					)
				)
			),
			'generationConfig' => array(
				'temperature'      => 0.2,
				'responseMimeType' => 'application/json'
			)
		);

		$response = wp_remote_post( $url, array(
			'headers'     => array( 'Content-Type' => 'application/json' ),
			'body'        => wp_json_encode( $payload ),
			'method'      => 'POST',
			'data_format' => 'body',
			'timeout'     => 45
		) );

		if ( is_wp_error( $response ) ) {
			wp_send_json_error( array( 'message' => 'Server connection failed: ' . $response->get_error_message() ) );
		}

		$status_code = wp_remote_retrieve_response_code( $response );
		$body = wp_remote_retrieve_body( $response );
		$data = json_decode( $body, true );

		if ( $status_code !== 200 ) {
			$err_msg = isset( $data['error']['message'] ) ? $data['error']['message'] : 'Unknown Error';
			wp_send_json_error( array( 'message' => 'AI API Error: ' . $err_msg ) );
		}

		if ( isset( $data['candidates'][0]['content']['parts'][0]['text'] ) ) {
			$json_txt = $data['candidates'][0]['content']['parts'][0]['text'];
			$json_txt = str_replace( array('```json', '```'), '', $json_txt );
			$result = json_decode( trim( $json_txt ), true );

			if ( json_last_error() === JSON_ERROR_NONE && is_array( $result ) ) {
				wp_send_json_success( $result );
			} else {
				wp_send_json_error( array( 'message' => 'AI returned an invalid format.' ) );
			}
		}

		wp_send_json_error( array( 'message' => 'AI could not process the image. Please try a clearer photo.' ) );
	}

	public function render_shortcode( $atts ) {
		wp_enqueue_script( 'jquery' );
		ob_start();
		$nonce = wp_create_nonce( 'pm_disease_nonce' );
		?>
		<style>
			.df-app { max-width: 600px; margin: 0 auto; background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.05); font-family: var(--font-body, system-ui, sans-serif); text-align: center; border: 1px solid #f0fdf4; }
			.df-header { padding: 15px 15px 5px; }
			.df-header h2 { font-size: 22px; font-weight: 900; color: #166534; line-height: 1.1; margin: 0 0 5px; }
			.df-badge { display: inline-block; background: #fbbf24; color: #fff; padding: 2px 8px; border-radius: 12px; font-size: 10px; font-weight: 800; letter-spacing: 1px; text-transform: uppercase; margin-bottom: 5px; }
			.df-body { padding: 5px 15px 15px; }
			.df-upload-area { border: 2px dashed #22c55e; border-radius: 16px; padding: 40px 15px; background: #f0fdf4; cursor: pointer; transition: 0.3s; position: relative; }
			.df-upload-area:hover { background: #dcfce7; }
			.df-upload-area.has-image { padding: 0; overflow: hidden; border-style: solid; background: #000; }
			.df-upload-area img { width: 100%; height: auto; max-height: 300px; object-fit: contain; display: block; }
			.df-upload-area input[type="file"] { position: absolute; inset: 0; width: 100%; height: 100%; opacity: 0; cursor: pointer; z-index: 10; }
			.df-btn { display: block; width: 100%; background: #22c55e; color: #fff; padding: 14px; border-radius: 10px; font-size: 16px; font-weight: 700; border: none; cursor: pointer; transition: 0.2s; margin-top: 15px; box-shadow: 0 4px 15px rgba(34,197,94,0.3); }
			.df-btn:hover { background: #16a34a; transform: translateY(-2px); }
			.df-btn:disabled { background: #9ca3af; cursor: not-allowed; box-shadow: none; transform: none; }
			.df-loader { display: none; padding: 20px; }
			.df-spinner { border: 4px solid #f3f3f3; border-top: 4px solid #22c55e; border-radius: 50%; width: 30px; height: 30px; animation: spin 1s linear infinite; margin: 0 auto; }
			.df-error { background: #fef2f2; color: #ef4444; padding: 10px; border-radius: 8px; margin-top: 15px; font-size: 14px; font-weight: 500; display: none; }
			.df-result { margin-top: 20px; text-align: left; display: none; animation: fadeIn 0.5s ease; }
			.df-diag-box { background: #fef2f2; border: 1px solid #fecaca; border-radius: 12px; padding: 15px; margin-bottom: 15px; }
			.df-diag-box h3 { color: #dc2626; font-size: 20px; font-weight: 900; margin: 0 0 5px; }
			.df-diag-box p { color: #7f1d1d; font-size: 14px; margin: 0; line-height: 1.5; }
			.df-treat-box { background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 12px; padding: 15px; }
			.df-treat-box h3 { color: #166534; font-size: 18px; font-weight: 800; margin: 0 0 5px; }
			.df-treat-box p { color: #14532d; font-size: 14px; margin: 0 0 15px; line-height: 1.5; }
			.df-amazon-btn { display: inline-block; background: #f59e0b; color: #fff !important; padding: 12px 20px; border-radius: 8px; text-decoration: none; font-weight: 700; font-size: 14px; box-shadow: 0 4px 10px rgba(245,158,11,0.3); text-align: center; width: 100%; box-sizing: border-box; }
			.df-amazon-btn:hover { background: #d97706; }
			@keyframes spin { 0% { transform: rotate(0deg); } 100% { transform: rotate(360deg); } }
			@keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
		</style>
		
		<div class="df-app">
			<div class="df-header">
				<h2>AI Plant Disease Finder</h2>
				<span class="df-badge">Premium Feature</span>
			</div>
			<div class="df-body">
				<div class="df-upload-area" id="dfUploadArea">
					<div id="dfUploadPrompt">
						<svg style="width:48px;height:48px;color:#22c55e;margin:0 auto 10px;" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 13a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
						<p style="font-weight:700;color:#166534;margin:0;">Tap to Take Photo or Upload</p>
					</div>
					<img id="dfPreview" src="" style="display:none;" />
					<input type="file" id="dfFileInput" accept="image/*" />
				</div>
				
				<div class="df-error" id="dfError"></div>

				<button class="df-btn" id="dfAnalyzeBtn" disabled>Analyze Plant</button>

				<div class="df-loader" id="dfLoader">
					<div class="df-spinner"></div>
					<p style="color:#166534;font-weight:600;margin-top:15px;">AI is analyzing your plant...</p>
				</div>

				<div class="df-result" id="dfResult">
					<div class="df-diag-box">
						<h3 id="dfDiagnosis"></h3>
						<p id="dfExplanation"></p>
					</div>
					<div class="df-treat-box">
						<h3>Recommended Treatment</h3>
						<p id="dfTreatmentDesc"></p>
						<a id="dfAmazonBtn" href="#" target="_blank" rel="noopener noreferrer" class="df-amazon-btn">Get Recommended Treatment</a>
					</div>
					<button class="df-btn" style="background:#4b5563;margin-top:20px;" onclick="location.reload()">Scan Another Plant</button>
				</div>
			</div>
		</div>

		<script>
		document.addEventListener("DOMContentLoaded", function() {
			// FORCE CLEANUP: Remove any Next.js iframes the user might have pasted
			document.querySelectorAll('iframe').forEach(function(iframe) {
				if (iframe.src && (iframe.src.includes('disease-finder') || iframe.src.includes('watering-calculator') || iframe.src.includes('72.62.93.117'))) {
					iframe.remove();
				}
			});
			
			// FORCE CLEANUP: Hide empty blocks (like the yellow box) left in WP Editor
			document.querySelectorAll('.tool-content div, .tool-content p').forEach(function(el) {
				if (el.innerHTML.trim() === '' && !el.classList.contains('df-app')) {
					el.style.display = 'none';
				}
			});
			
			// FORCE CLEANUP: If shortcode is rendered multiple times, keep only the first one
			const allApps = document.querySelectorAll('.df-app');
			if (allApps.length > 1) {
				for (let i = 1; i < allApps.length; i++) {
					allApps[i].remove();
				}
			}

			const fileInput = document.getElementById('dfFileInput');
			const preview = document.getElementById('dfPreview');
			const uploadPrompt = document.getElementById('dfUploadPrompt');
			const uploadArea = document.getElementById('dfUploadArea');
			const analyzeBtn = document.getElementById('dfAnalyzeBtn');
			const errorBox = document.getElementById('dfError');
			const loader = document.getElementById('dfLoader');
			const resultBox = document.getElementById('dfResult');
			
			let base64Image = null;

			fileInput.addEventListener('change', function(e) {
				const file = e.target.files[0];
				if (!file) return;

				if (file.size > 5 * 1024 * 1024) {
					showError("Image is too large. Max size is 5MB.");
					return;
				}

				const reader = new FileReader();
				reader.onload = function(event) {
					base64Image = event.target.result;
					preview.src = base64Image;
					preview.style.display = 'block';
					uploadPrompt.style.display = 'none';
					uploadArea.classList.add('has-image');
					analyzeBtn.disabled = false;
					errorBox.style.display = 'none';
				};
				reader.readAsDataURL(file);
			});

			function showError(msg) {
				errorBox.innerText = msg;
				errorBox.style.display = 'block';
				loader.style.display = 'none';
				analyzeBtn.disabled = false;
				analyzeBtn.style.display = 'block';
			}

			analyzeBtn.addEventListener('click', function() {
				if (!base64Image) return;

				analyzeBtn.style.display = 'none';
				uploadArea.style.display = 'none';
				errorBox.style.display = 'none';
				loader.style.display = 'block';

				jQuery.ajax({
					url: '<?php echo esc_url( admin_url( 'admin-ajax.php' ) ); ?>',
					type: 'POST',
					data: {
						action: 'pm_analyze_disease',
						_wpnonce: '<?php echo $nonce; ?>',
						image_base64: base64Image
					},
					success: function(res) {
						loader.style.display = 'none';
						if (res.success && res.data) {
							const data = res.data;
							document.getElementById('dfDiagnosis').innerText = data.diagnosis;
							document.getElementById('dfExplanation').innerText = data.explanation;
							document.getElementById('dfTreatmentDesc').innerText = data.treatment_desc;
							
							const query = encodeURIComponent(data.treatment_keyword);
							document.getElementById('dfAmazonBtn').href = `https://www.amazon.com/s?k=${query}&tag=plantsmag-20`;
							
							resultBox.style.display = 'block';
							resultBox.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
						} else {
							showError(res.data?.message || 'Failed to analyze image.');
							uploadArea.style.display = 'block';
						}
					},
					error: function() {
						showError('Network error. Please try again.');
						uploadArea.style.display = 'block';
					}
				});
			});
		});
		</script>
		<?php
		return ob_get_clean();
	}
}

new PlantsMag_Disease_Finder();
