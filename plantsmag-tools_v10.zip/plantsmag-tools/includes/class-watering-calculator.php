<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class PlantsMag_Watering_Calculator {

	public function __construct() {
		add_shortcode( 'watering_calculator', array( $this, 'render_shortcode' ) );
	}

	public function render_shortcode( $atts ) {
		ob_start();
		?>
		<style>
			.wc-app { max-width: 600px; margin: 0 auto; background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.05); font-family: var(--font-body, system-ui, sans-serif); border: 1px solid #f0fdf4; }
			.wc-header { background: #047857; padding: 10px; text-align: center; }
			.wc-header h2 { color: #fff; margin: 0; font-size: 20px; font-weight: 800; display: flex; align-items: center; justify-content: center; gap: 8px; line-height: 1.2; }
			.wc-body { padding: 10px 15px 15px; }
			.wc-group { margin-bottom: 15px; }
			.wc-label { display: flex; align-items: center; gap: 6px; font-size: 14px; font-weight: 700; color: #374151; margin-bottom: 8px; }
			.wc-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 8px; }
			.wc-btn-opt { background: #fff; border: 2px solid #e5e7eb; padding: 10px; border-radius: 10px; font-size: 12px; font-weight: 600; color: #4b5563; cursor: pointer; text-align: left; transition: all 0.2s; outline: none; }
			.wc-btn-opt.active { background: #eff6ff; border-color: #3b82f6; color: #1d4ed8; }
			.wc-select { width: 100%; padding: 12px; background: #f9fafb; border: 2px solid #e5e7eb; border-radius: 10px; outline: none; font-size: 14px; color: #374151; font-weight: 500; appearance: none; }
			.wc-select:focus { border-color: #3b82f6; background: #fff; }
			.wc-btn-calc { width: 100%; background: #2563eb; color: #fff; border: none; padding: 14px; border-radius: 12px; font-size: 16px; font-weight: 700; cursor: pointer; margin-top: 5px; transition: 0.2s; box-shadow: 0 4px 15px rgba(37,99,235,0.3); }
			.wc-btn-calc:hover { background: #1d4ed8; transform: translateY(-2px); }
			.wc-result { margin-top: 20px; text-align: center; display: none; animation: fadeIn 0.5s ease; }
			.wc-result-box { background: linear-gradient(to bottom right, #eff6ff, #ecfeff); border: 1px solid #bfdbfe; border-radius: 12px; padding: 20px; }
			.wc-result h3 { font-size: 32px; font-weight: 900; color: #1d4ed8; margin: 10px 0; line-height: 1; }
			.wc-advice { background: rgba(255,255,255,0.8); padding: 12px; border-radius: 10px; text-align: left; font-size: 14px; color: #1e40af; border: 1px solid #bfdbfe; margin-top: 15px; display: flex; gap: 8px; font-weight: 500; }
			.wc-pro-tip { margin-top: 15px; background: #fffbeb; border: 1px solid #fef3c7; padding: 15px; border-radius: 12px; text-align: left; }
			.wc-amazon-btn { display: block; background: #f59e0b; color: #fff !important; padding: 12px; border-radius: 10px; text-decoration: none; font-weight: 800; font-size: 14px; margin-top: 12px; box-shadow: 0 4px 12px rgba(245,158,11,0.3); transition: 0.2s; text-align: center; }
			.wc-amazon-btn:hover { background: #d97706; transform: translateY(-2px); }
			@keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
		</style>
		
		<div class="wc-app" id="wcApp">
			<div class="wc-header">
				<h2>💧 Smart Watering</h2>
			</div>
			<div class="wc-body">
				<!-- Plant Type -->
				<div class="wc-group">
					<div class="wc-label">🌱 Plant Type</div>
					<div class="wc-grid" id="wcPlantType">
						<button class="wc-btn-opt active" data-val="tropical">Tropical (Monstera, Pothos)</button>
						<button class="wc-btn-opt" data-val="succulent">Succulent</button>
						<button class="wc-btn-opt" data-val="cacti">Cactus</button>
						<button class="wc-btn-opt" data-val="fern">Fern / Calathea</button>
					</div>
				</div>
				<!-- Light Exposure -->
				<div class="wc-group">
					<div class="wc-label">☀️ Light Exposure</div>
					<select class="wc-select" id="wcLight">
						<option value="low">Low Light (North window)</option>
						<option value="medium" selected>Medium Light (East window)</option>
						<option value="bright">Bright Indirect (South/West window)</option>
						<option value="direct">Direct Sun (Unfiltered South)</option>
					</select>
				</div>
				<!-- Soil Type -->
				<div class="wc-group">
					<div class="wc-label">🪨 Soil Drainage</div>
					<select class="wc-select" id="wcSoil">
						<option value="perlite">Chunky / Well-Draining</option>
						<option value="standard" selected>Standard Potting Mix</option>
						<option value="peat">Moisture Retaining</option>
						<option value="sandy">Sandy (Cactus Mix)</option>
					</select>
				</div>
				<!-- Pot Size -->
				<div class="wc-group">
					<div class="wc-label">🪴 Pot Size</div>
					<div class="wc-grid" id="wcPot" style="grid-template-columns: 1fr 1fr 1fr;">
						<button class="wc-btn-opt" data-val="small">Small (&lt; 6")</button>
						<button class="wc-btn-opt active" data-val="medium">Medium (6"-10")</button>
						<button class="wc-btn-opt" data-val="large">Large (&gt; 10")</button>
					</div>
				</div>

				<button class="wc-btn-calc" id="wcCalcBtn">Calculate Schedule</button>

				<div class="wc-result" id="wcResult">
					<div class="wc-result-box">
						<p style="color: #1e40af; font-weight: 700; margin:0 0 5px 0;">Estimated Watering Frequency:</p>
						<h3 id="wcFreq">Every 7 to 9 Days</h3>
						<div class="wc-advice">
							<span style="font-size:20px;">ℹ️</span>
							<span id="wcAdviceText">Always check the top 2 inches of soil before watering.</span>
						</div>
					</div>
					<div class="wc-pro-tip">
						<p style="color: #92400e; font-size: 14px; margin:0; line-height:1.5;"><strong>Pro Tip:</strong> Stop guessing when to water. A simple moisture meter is the best investment for your plants.</p>
						<a href="https://www.amazon.com/dp/B01IGQOIN2?tag=plantsmag-20" target="_blank" rel="noopener noreferrer" class="wc-amazon-btn">Get a Digital Moisture Meter</a>
					</div>
				</div>
			</div>
		</div>

		<script>
		document.addEventListener("DOMContentLoaded", function() {
			// FORCE CLEANUP: Remove any Next.js iframes the user might have pasted
			document.querySelectorAll('iframe').forEach(function(iframe) {
				if (iframe.src && (iframe.src.includes('disease-finder') || iframe.src.includes('watering-calculator') || iframe.src.includes('72.62.93.117'))) {
					iframe.remove();
				}
			});
			
			// FORCE CLEANUP: If shortcode is rendered multiple times, keep only the first one
			const allApps = document.querySelectorAll('.wc-app');
			if (allApps.length > 1) {
				for (let i = 1; i < allApps.length; i++) {
					allApps[i].remove();
				}
			}

			let state = { plantType: "tropical", lightLevel: "medium", soilType: "standard", potSize: "medium" };

			function setupButtons(containerId, key) {
				const container = document.getElementById(containerId);
				const btns = container.querySelectorAll('.wc-btn-opt');
				btns.forEach(btn => {
					btn.addEventListener('click', () => {
						btns.forEach(b => b.classList.remove('active'));
						btn.classList.add('active');
						state[key] = btn.getAttribute('data-val');
					});
				});
			}

			setupButtons('wcPlantType', 'plantType');
			setupButtons('wcPot', 'potSize');

			document.getElementById('wcLight').addEventListener('change', (e) => state.lightLevel = e.target.value);
			document.getElementById('wcSoil').addEventListener('change', (e) => state.soilType = e.target.value);

			document.getElementById('wcCalcBtn').addEventListener('click', () => {
				let baseDays = 7;
				switch (state.plantType) {
					case "succulent": baseDays = 14; break;
					case "cacti": baseDays = 21; break;
					case "fern": baseDays = 4; break;
					case "tropical": baseDays = 7; break;
				}

				let lightMultiplier = 1;
				switch (state.lightLevel) {
					case "low": lightMultiplier = 1.3; break;
					case "medium": lightMultiplier = 1; break;
					case "bright": lightMultiplier = 0.8; break;
					case "direct": lightMultiplier = 0.6; break;
				}

				let soilMultiplier = 1;
				switch (state.soilType) {
					case "peat": soilMultiplier = 1.2; break;
					case "standard": soilMultiplier = 1; break;
					case "perlite": soilMultiplier = 0.8; break;
					case "sandy": soilMultiplier = 0.6; break;
				}

				let potMultiplier = 1;
				switch (state.potSize) {
					case "small": potMultiplier = 0.7; break;
					case "medium": potMultiplier = 1; break;
					case "large": potMultiplier = 1.5; break;
				}

				let finalDays = Math.round(baseDays * lightMultiplier * soilMultiplier * potMultiplier);
				if (finalDays < 1) finalDays = 1;
				if (finalDays > 30) finalDays = 30;

				let advice = "Always check the top 2 inches of soil before watering.";
				if (state.plantType === "succulent" || state.plantType === "cacti") {
					advice = "Wait until the soil is completely 100% dry before watering again.";
				} else if (state.plantType === "fern") {
					advice = "Keep the soil consistently moist, but not soggy.";
				}

				let range = `${Math.max(1, finalDays - 1)} to ${finalDays + 2}`;
				
				document.getElementById('wcFreq').innerText = `Every ${range} Days`;
				document.getElementById('wcAdviceText').innerText = advice;
				document.getElementById('wcResult').style.display = 'block';
				
				// Smooth scroll to result
				document.getElementById('wcResult').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
			});
		});
		</script>
		<?php
		return ob_get_clean();
	}
}

new PlantsMag_Watering_Calculator();
